
from .model3dgs import Model3DGS

__all__ = ['Model3DGS']
