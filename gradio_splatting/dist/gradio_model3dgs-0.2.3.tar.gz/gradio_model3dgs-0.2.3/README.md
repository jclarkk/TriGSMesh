
# gradio_model3dgs
A Custom Gradio component.

## Example usage

```python
import gradio as gr
from gradio_model3dgs import Model3DGS
```
